-- Blade Overdrive Online: Supabase schema
-- Run in Supabase Dashboard > SQL Editor as project owner.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[A-Za-z0-9_]{3,20}$'),
  created_at timestamptz not null default now()
);

create table if not exists public.scores (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  score integer not null check (score >= 0 and score <= 100000000),
  mode text not null check (mode in ('endless','time','precision')),
  wave integer not null check (wave between 1 and 10000),
  accuracy numeric(5,2) not null check (accuracy between 0 and 100),
  max_combo integer not null check (max_combo between 0 and 100000),
  targets_sliced integer not null check (targets_sliced between 0 and 1000000),
  duration_seconds integer not null check (duration_seconds between 0 and 86400),
  created_at timestamptz not null default now(),
  flagged boolean not null default false
);

create index if not exists scores_leaderboard_idx on public.scores (mode, score desc, created_at desc) where flagged = false;
create index if not exists scores_user_history_idx on public.scores (user_id, created_at desc);
create index if not exists profiles_username_search_idx on public.profiles (lower(username));

create or replace function public.handle_new_blade_user()
returns trigger language plpgsql security definer set search_path = '' as $$
declare candidate text;
begin
  candidate := coalesce(new.raw_user_meta_data ->> 'username', split_part(coalesce(new.email, 'pilot'), '@', 1));
  candidate := regexp_replace(candidate, '[^A-Za-z0-9_]', '', 'g');
  candidate := left(candidate, 20);
  if length(candidate) < 3 then candidate := 'Pilot_' || left(replace(new.id::text, '-', ''), 8); end if;
  if exists (select 1 from public.profiles p where lower(p.username) = lower(candidate)) then
    candidate := left(candidate, 11) || '_' || left(replace(new.id::text, '-', ''), 8);
  end if;
  insert into public.profiles(id, username) values (new.id, candidate)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_blade on auth.users;
create trigger on_auth_user_created_blade after insert on auth.users
for each row execute procedure public.handle_new_blade_user();

alter table public.profiles enable row level security;
alter table public.scores enable row level security;

drop policy if exists "Public can view profiles" on public.profiles;
create policy "Public can view profiles" on public.profiles for select to anon, authenticated using (true);
drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists "Public can view non-flagged scores" on public.scores;
create policy "Public can view non-flagged scores" on public.scores for select to anon, authenticated using (flagged = false);
-- Intentionally no client INSERT/UPDATE/DELETE policy on scores. Only the Edge Function's service role inserts scores.

grant usage on schema public to anon, authenticated;
grant select on public.profiles, public.scores to anon, authenticated;
grant update(username) on public.profiles to authenticated;
