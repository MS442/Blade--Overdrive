// Supabase Edge Function: authenticated, basic sanity-checked score submission.
// Deploy with SUPABASE_URL, SUPABASE_ANON_KEY and SUPABASE_SERVICE_ROLE_KEY secrets.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Sign in before submitting scores." }, 401);
    const url = Deno.env.get("SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !anonKey || !serviceKey) return json({ error: "Server configuration is incomplete." }, 500);
    const userClient = createClient(url, anonKey, { global: { headers: { Authorization: authHeader } }, auth: { persistSession: false } });
    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) return json({ error: "Your session is invalid. Sign in again." }, 401);
    const body = await req.json();
    const mode = String(body.mode || "");
    const score = Number(body.score), wave = Number(body.wave), accuracy = Number(body.accuracy);
    const max_combo = Number(body.max_combo), targets_sliced = Number(body.targets_sliced), duration_seconds = Number(body.duration_seconds);
    if (!["endless", "time", "precision"].includes(mode)) return json({ error: "Invalid game mode." }, 400);
    const ints = [score, wave, max_combo, targets_sliced, duration_seconds];
    if (!ints.every(Number.isSafeInteger) || !Number.isFinite(accuracy)) return json({ error: "Invalid score payload." }, 400);
    if (score < 0 || score > 100000000 || wave < 1 || wave > 10000 || accuracy < 0 || accuracy > 100 || max_combo < 0 || max_combo > 100000 || targets_sliced < 0 || targets_sliced > 1000000 || duration_seconds < 0 || duration_seconds > 86400) return json({ error: "Score values are outside permitted limits." }, 400);
    // Basic anomaly guard, not proof against client tampering. Keep thresholds permissive for future balance changes.
    if ((mode === "time" && duration_seconds > 120) || (mode === "precision" && targets_sliced > 5000)) return json({ error: "Run statistics failed validation." }, 400);
    const admin = createClient(url, serviceKey, { auth: { persistSession: false } });
    const { data: recent, error: recentError } = await admin.from("scores").select("id").eq("user_id", user.id).gte("created_at", new Date(Date.now() - 5000).toISOString()).limit(1);
    if (recentError) return json({ error: "Could not validate submission." }, 500);
    if (recent?.length) return json({ error: "Please wait a few seconds before submitting another score." }, 429);
    const { error: insertError } = await admin.from("scores").insert({ user_id: user.id, score, mode, wave, accuracy, max_combo, targets_sliced, duration_seconds });
    if (insertError) return json({ error: "Score could not be saved." }, 500);
    return json({ ok: true, message: "Score submitted to the global leaderboard!" }, 201);
  } catch (_error) {
    return json({ error: "Invalid request." }, 400);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
