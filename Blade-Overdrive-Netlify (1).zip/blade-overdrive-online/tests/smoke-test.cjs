const fs = require('fs');
const vm = require('vm');
const html = fs.readFileSync('game.html', 'utf8');
const checks = [
  ['Supabase client loaded', html.includes('@supabase/supabase-js@2')],
  ['Global leaderboard UI', html.includes('id="leaderboardModal"') && html.includes('id="leaderboardRows"')],
  ['Email auth UI', html.includes('id="authForm"') && html.includes('id="signUpBtn"')],
  ['Google OAuth is disabled in the public frontend', !html.includes("signInWithOAuth({ provider: 'google'") && !html.includes('id="googleSignInBtn"')],
  ['Email confirmation returns to current origin', html.includes('emailRedirectTo: window.location.origin')],
  ['Score submission hook', html.includes("functions.invoke('submit-score'")],
  ['No service-role key in frontend', !html.includes('SUPABASE_SERVICE_ROLE_KEY')],
  ['Game over submits run', html.includes('submitFinishedRun({')],
  ['Supabase project configured', html.includes('https://qaomvgwryemkrycfjbzk.supabase.co') && !html.includes('YOUR_SUPABASE_PROJECT_URL')],
  ['Pagination controls', html.includes('leaderboardNextBtn') && html.includes('leaderboardPrevBtn')],
];
let failed = false;
for (const [name, ok] of checks) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed = true; }
const script = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)].map(m => m[1]).filter(s => s.trim() && !s.includes('tailwind.config'));
for (const [i, body] of script.entries()) {
  try { new vm.Script(body, { filename: `inline-script-${i + 1}.js` }); console.log(`PASS inline JavaScript syntax ${i + 1}`); }
  catch (e) { console.error(`FAIL inline JavaScript syntax ${i + 1}: ${e.message}`); failed = true; }
}
const schema = fs.readFileSync('supabase/schema.sql', 'utf8');
const edge = fs.readFileSync('supabase/functions/submit-score/index.ts', 'utf8');
for (const [name, ok] of [
  ['RLS enabled for scores', schema.includes('alter table public.scores enable row level security')],
  ['No direct score insert policy', !/create policy[^;]*on public\.scores[^;]*for insert/i.test(schema)],
  ['Edge function authenticates user', edge.includes('auth.getUser()')],
  ['Edge function validates mode and score', edge.includes('Invalid game mode') && edge.includes('outside permitted limits')],
  ['Edge function has rate limiting', edge.includes('Please wait a few seconds')],
]) { console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`); if (!ok) failed = true; }
if (failed) process.exit(1);
